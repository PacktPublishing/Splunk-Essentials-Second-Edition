# splunk-external-dashboard

### Used in the Splunk Essentials Second Edition Book by Packt Publishing
